<?php
$wo['description'] = $wo['config']['siteDesc'];
$wo['keywords']    = $wo['config']['siteKeywords'];
$wo['page']        = 'maintenance';
$wo['title']       = $wo['config']['siteTitle'];
$wo['content']     = Wo_LoadPage('maintenance/content');