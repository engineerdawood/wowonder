<?php
$wo['description'] = '';
$wo['keywords']    = '';
$wo['page']        = 'search';
$wo['title']       = $wo['lang']['search'] . ' | ' . $wo['config']['siteTitle'];
$wo['content']     = Wo_LoadPage('search/content');